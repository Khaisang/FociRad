%%input_image
MNC_image=imread('MNC_image.tif');
dummy=zeros(size(CD45));


%% Green Channel extraction
Merge_image=cat(3,dummy(:,:,1),MNC(:,:,2),dummy(:,:,3));

imwrite(Green_Chanel,'Green_image.png');