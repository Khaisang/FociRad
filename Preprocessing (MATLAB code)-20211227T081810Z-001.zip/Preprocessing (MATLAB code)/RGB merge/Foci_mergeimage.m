%%input_image
CD45=imread('CD45_image.tif');
gamma_H2AX=imread('gamma_H2AX_image.tif');
Nucleus=imread('Nucleus_image.tif');
dummy=zeros(size(CD45));


%% Median filter
CD45_med=imfilt2(CD45(:,:,1),[3 3]);
gamma_med=imfilt2(gamma_H2AX(:,:,2),[3 3]);
Nucleus_med=imfilt2(Nucleus(:,:,3),[3 3]);
%% Gaussian_filter
CD45_gaus=imgaussfilt(CD45_med,0.5);
gamma_gaus=imgaussfilt(gamma_med,0.5);
Nucleus_gaus=imgaussfilt(Nucleus_med,0.5);

%% merge image
Merge_image=cat(3,CD45_gaus,gamma_gaus,Nucleus_gaus);

imwrite(Merge_image,'merge_image.png');